# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['charmonium', 'charmonium.async_subprocess']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'charmonium.async-subprocess',
    'version': '0.1.1',
    'description': 'async clone of subprocess.run',
    'long_description': None,
    'author': 'Samuel Grayson',
    'author_email': 'sam@samgrayson.me',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
